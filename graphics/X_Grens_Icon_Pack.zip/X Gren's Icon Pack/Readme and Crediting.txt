Hello there, and thank you for deciding to choose the X Gren Icon Pack!

Foremost I would like to give credit to the DS styles (https://www.pokecommunity.com/showthread.php?t=368703) and Gen 8 Sprite Project (https://docs.google.com/spreadsheets/d/1acgzAjh0dnFRQnjZu8kSjS177rKCzpFfEHRLtwuuXRU/edit#gid=1115705090).
These two assets allowed me to get my feet off the ground and make this pack so that hopefully you don't have to. On the subject of crediting, it would be nice if you
did. 

Secondly, I have not included Gigantamax up to this point as I'm unsure of what to do with it. Gen 8 Sprite Project includes small varients of Gigantamax forms, however
these do not fit in the alotted 32 x 32 cell size. As a result, if push comes to shove, I have ideas on what TO do I'm just holding off for something better.
Nonetheless all proper Gen 8 Pokemon are to their best inclusion in current DPE. 

Likewise I did not include sprites for the Galar varients of Weezing and Mime Jr, though I would if I knew how.

As for the sprite pack itself, its fairly simple. Drag and drop your sprites into DPE's Icon Graphics folder, and move the Icon_Pallete_Data.c folder to DPE's SRC 
folder. 

Enjoy!